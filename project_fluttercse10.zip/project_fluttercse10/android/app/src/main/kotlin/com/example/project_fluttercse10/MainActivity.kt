package com.example.project_fluttercse10

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
